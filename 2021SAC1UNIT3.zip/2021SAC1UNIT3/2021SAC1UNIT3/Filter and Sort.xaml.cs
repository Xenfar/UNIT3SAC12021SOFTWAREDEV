﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _2021SAC1UNIT3
{
    /// <summary>
    /// Interaction logic for Filter_and_Sort.xaml
    /// </summary>
    public partial class Filter_and_Sort : Window
    {
        Sale[] sales;
       
        public Filter_and_Sort(Sale[] _sales)
        {
            InitializeComponent();
            sales = _sales;
        }

        private void subjectFilterButton_Click(object sender, RoutedEventArgs e)
        {
            string subjectFilter = subjectInput.Text;
            for (int i = 0; i < sales.Length; i++)
            {
                if (sales[i].Subject == subjectFilter)
                {
                    sales[i].readOut();
                }
            }

        }

        private void textbookFilterButton_Click(object sender, RoutedEventArgs e)
        {
            string textbookNameFilter = textbookNameInput.Text;
            for (int i = 0; i < sales.Length; i++)
            {
                if (sales[i].Textbook == textbookNameFilter)
                {
                    sales[i].readOut();
                }
            }
        }

        private void ratingSortButton_Click(object sender, RoutedEventArgs e)
        {
            int[] ratings = new int[sales.Length];
            for (int i = 0; i < sales.Length; i++)
            {
                if (sales[i].Rating != "none")
                {
                    ratings[i] = Int32.Parse(sales[i].Rating);
                }
                else
                {
                    ratings[i] = 0;
                }

            }
            int[] sorts = quickSort(ratings, 0, sales.Length);

            for (int i = 0; i < sorts.Length; i++)
            {
                contentBox.Text = sales[sorts[i]].readOut();

            }
        }

        public int[] quickSort(int[] ratings, int low, int high)
        {
            if (low < high)
            {
                int pivot = partition(ratings, low, high);

                if (pivot > 1)
                {
                    quickSort(ratings, low, pivot - 1);
                }
                if (pivot + 1 < high)
                {
                    quickSort(ratings, pivot + 1, high);
                }
            }
            return ratings;

        }

        private int partition(int[] vals, int low, int high)
        {
            int pivot = vals[low];
            while (true)
            {

                while (vals[low] < pivot)
                {
                    low++;
                }

                while (vals[high] > pivot)
                {
                    high--;
                }

                if (low < high)
                {
                    if (vals[low] == vals[high])
                    {

                        return high;
                    }

                    int temp = vals[low];
                    vals[low] = vals[high];
                    vals[high] = temp;


                }
                else
                {
                    return high;
                }
            }
        }
    }
}
