﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2021SAC1UNIT3
{
    public class Sale
    {
        //I was having conversion issues with my library, treat salePrice, purchasePrice and rating the same as float float and int
        public string Textbook { get; set; }
        public string Subject { get; set; }
        public string Seller { get; set; }
        public string PurchasePrice { get; set; }
        public string Purchaser { get; set; }

        public string SalePrice { get; set; }
        public string Rating { get; set; }

        public string readOut()
        {
            return " 'textbook': '" + Textbook + "', 'subject': '" + Subject + "', 'seller': '" + Seller + System.Environment.NewLine + "', 'purchasePrice': '" + PurchasePrice + "', 'purchaser': '" + Purchaser + "', 'salePrice': '" + SalePrice + "', 'rating': " + Rating;
        }
    }
}
