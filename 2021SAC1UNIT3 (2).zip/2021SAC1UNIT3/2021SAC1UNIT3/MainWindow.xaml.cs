﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CsvHelper;
namespace _2021SAC1UNIT3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Sale[] sales;
        public float colPrice = 0f;
        public MainWindow()
        {
            InitializeComponent();
            readRecords();
            dispGrid.ItemsSource = sales;
            /*for (int i = 0; i < sales.Length; i++)
            {
                Console.WriteLine(sales[i].Textbook);
            }*/

        }
        public void readRecords()
        {
            sales = Read();
        }
        private Sale[] Read()
        {

            Sale[] _sales;
            using (var reader = new StreamReader(@"shop_data.csv"))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var records = csv.GetRecords<Sale>();

                _sales = records.ToArray();
            }

            

            return _sales;
        }
        private float GetProfit()
        {
            float cumulativeProfit = 0f;
            Console.WriteLine("Sales length: " + sales.Length);
            for(int i = 0; i < sales.Length; i++)
            {
                float profit = 0f; 
                if (sales[i].SalePrice != "NA")
                {
                    profit = (float.Parse(sales[i].SalePrice) - float.Parse(sales[i].PurchasePrice));
                }
                else
                {
                    profit = -(float.Parse(sales[i].PurchasePrice));
                }
                //repeating too many times, should only repeat once
                cumulativeProfit += profit;
                if (i % 2 == 0)
                {
                    priceBox.Content += " | " + sales[i].Textbook + "---" + " $" + profit;
                }
                else
                {
                    priceBox.Content += System.Environment.NewLine + sales[i].Textbook + "---" + " $" + profit;
                }
                
            }
            
            return cumulativeProfit;
        }

        private void CalculateWorthButton_Click(object sender, RoutedEventArgs e)
        {
            double age = Int32.Parse(ageInput.Text);
            double parPrice = Int32.Parse(payInput.Text);

            double currentPrice = parPrice - ((age * 0.2) * parPrice);
            worthDisp.Content = "The textbook is worth: $" + currentPrice;
            collectiveWorthDisp.Content = "The collection is worth: $" + Math.Round( colPrice + currentPrice, 2); 
        }

        private void calcProfitButton_Click(object sender, RoutedEventArgs e)
        {
            priceBox.Content = " ";
            totalProfDisp.Content = "Total Profit Is: $" + GetProfit();
        }

        private void Rating_Click(object sender, RoutedEventArgs e)
        {
            RatingPopup rp = new RatingPopup(sales, this);
            rp.ShowDialog();
        }

        private void Filter_and_Sort_Click(object sender, RoutedEventArgs e)
        {
            Filter_and_Sort fs = new Filter_and_Sort(sales);
            fs.ShowDialog();
        }
    }


}
