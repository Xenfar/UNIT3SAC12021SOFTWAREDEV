﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _2021SAC1UNIT3
{
    /// <summary>
    /// Interaction logic for RatingPopup.xaml
    /// </summary>
    public partial class RatingPopup : Window
    {
        Sale[] sales;
        MainWindow mainWindow;
        public RatingPopup(Sale[] _sales, MainWindow mw)
        {
            InitializeComponent();
            sales = _sales;
            mainWindow = mw;
        }

        private void RatingChangeButton_Click(object sender, RoutedEventArgs e)
        {
            int newRating;
            try
            {
                newRating = Int32.Parse(ratingInput.Text);
            }
            catch
            {
                MessageBox.Show("Please input an integer value between one and five");
                return;
            }
            int id = search(textbookNameInput.Text, nameInput.Text);
            string oldrating = sales[id].Rating;
       
            sales[id].Rating = newRating.ToString();
            try
            {
                writeToFile();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                this.Close();
            }
            
            MessageBox.Show("Rating for: " + sales[id].Textbook + " has been updated from " + oldrating + "to: " + sales[id].Rating);
            this.Close();

        }
        void writeToFile()
        {
            using (var writer = new StreamWriter(@"shop_data.csv"))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.WriteRecords(sales);
            }
            
            mainWindow.readRecords();
        }
        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string textbookName;
            string purchaserName;
            
            try
            {
                textbookName = textbookNameInput.Text;
                purchaserName = nameInput.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please input textbook name and purchaser name in correct format (no numbers or special characters}");
                return;
            }
            search(textbookName, purchaserName);
        }
        int search(string textbookName, string purchaserName)
        {
            int saleID = -1;


            for (int i = 0; i < sales.Length; i++)
            {
                if (sales[i].Textbook == textbookName && sales[i].Purchaser == purchaserName)
                {
                    
                    saleID = i;
                }
            }
            if (saleID != -1)
            {
                contentBox.Content = "Found It! { " + sales[saleID].readOut() + "}";
            }
            else
            {
                MessageBox.Show("The book you are looking for could not be found, please ensure that you have typed the title of the book and your full name correctly");
            }

            return saleID;
        }
    }
}
